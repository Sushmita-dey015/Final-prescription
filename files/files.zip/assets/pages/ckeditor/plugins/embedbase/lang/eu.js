/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'eu', {
	pathName: 'multimedia objektua',
	title: 'Media Embed',
	button: 'Txertatu edukia',
	unsupportedUrlGiven: 'Ez dago zehazturiko URLarentzako euskarririk',
	unsupportedUrl: 'Media Embed-ek ez dauka {url} URLarentzako euskarririk.',
	fetchingFailedGiven: 'Huts egin du emandako URLetik edukia eskuratzean.',
	fetchingFailed: 'Huts egin du {url}(e)tik edukia eskuratzean.',
	fetchingOne: 'oEmbed erantzuna eskuratzen...',
	fetchingMany: 'oEmbed erantzunak eskuratzen, {current} / {max}'
} );
