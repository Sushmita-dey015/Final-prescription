/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'autoembed', 'km', {
	embeddingInProgress: 'កំពុង​ព្យាយាម​បង្កប់ URL ដែល​បាន​បិទភ្ជាប់...',
	embeddingFailed: 'មិន​អាច​បង្កប់ URL នេះ​ដោយ​ស្វ័យប្រវត្តិ​ទេ។'
} );
